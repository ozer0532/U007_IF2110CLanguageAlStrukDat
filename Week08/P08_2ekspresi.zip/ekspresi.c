// Nama / NIM : Chokyi Ozer
// Tanggal : 17 Oktober 2019
// Topik : ADT Stack
// Deskripsi : Mencetak hasil ekspresi

#include <stdio.h>
#include <math.h>
#include "stackt.h"
#include "mesintoken.h"

int main () {
	// KAMUS
	Stack S;
	int val;
	int x, y, res;
	
	// ALGORITMA
	CreateEmpty(&S);
	STARTTOKEN();
	if (!EndToken) {
		while (!EndToken) {
			if (CToken.tkn == 'b') {
				printf("%d\n", CToken.val);
				Push(&S, CToken.val);
			} else {
				Pop(&S, &y);
				Pop(&S, &x);
				printf("%d %c %d\n", x, CToken.tkn, y);
				if (CToken.tkn == '+') {
					res = x+y;
				} else if (CToken.tkn == '-') {
					res = x-y;
				} else if (CToken.tkn == '*') {
					res = x*y;
				} else if (CToken.tkn == '/') {
					res = x/y;
				} else if (CToken.tkn == '^') {
					res = pow(x, y);
				}
				printf("%d\n", res);
				Push(&S, res);
			}
			ADVTOKEN();
		}
		Pop(&S, &res);
		printf("Hasil=%d\n", res);
	} else {
		printf("Ekspresi kosong\n");
	}
	
}
