// NAMA / NIM - CHOKYI OZER 13518107
// TANGGAL - 12 SEP 2019
// Topik - ARRAY DINAMIS
// DESKRIPSI - Program melakukan berbagai operasi alokasi pada array

#include <stdio.h>
#include "arraydin.h"
#include "boolean.h"

int main () {
	// KAMUSH
	int M;
	TabInt T;
	int Q, op, num;
	int i;
	boolean success;
	
	// ALGORITMAS
	scanf("%d", &M);
	MakeEmpty(&T, M);
	
	BacaIsi(&T);
	scanf("%d", &Q);
	
	for (i = 0; i < Q; i++) {
		scanf("%d", &op);
		success = false;
		switch (op) {
			case 1:
				scanf("%d", &num);
				if (IsFull(T)) {
					printf("array sudah penuh\n");
				} else {
					AddAsLastEl(&T, num);
					success = true;
				}
				break;
			case 2:
				scanf("%d", &num);
				GrowTab(&T, num);
					success = true;
				break;
			case 3:
				scanf("%d", &num);
				if (MaxEl(T) >= num) {
					ShrinkTab(&T, num);
					success = true;
				} else {
					printf("array terlalu kecil\n");
				}
				break;
			case 4:
				CompactTab(&T);
				success = true;
				break;
		}
		
		if (success) {
			printf("%d ", MaxEl(T));
			TulisIsiTab(T);
			printf("\n");
		}
		
	}
	
	
	return 0;
}
